jQuery(function ( $ ) {
	$("#elementor-panel-footer-templates").addClass('OKKKKKKKK');
});
