/**
 * @file
 *  Основен файл за javascript обработващи функции.
 */
jQuery(document).ready(function($){
	
});